﻿#include <iostream>
#include <string>
using namespace std;

// Exception classes
class FullStack {}; // Exception if stack is full
class EmptyStack {}; // Exception if stack is empty

const int MAX_ITEMS = 20; // Max size of stack

enum RelationType { LESS, GREATER, EQUAL };

class ItemType 
{
private:
    int value;
public:
    // Compare two items
    RelationType ComparedTo(ItemType otherItem) const
    {
        if (value < otherItem.value)
            return LESS;
        else if (value > otherItem.value) 
            return GREATER;
        else 
            return EQUAL;
    }
    // Print value
    void Print(ostream& out) const
    { 
        out << value;
    }
    void Initialize(int number)
    { 
        value = number;
    }
};
//Generic Stack Class (Array-based)
template <class T>
class StackType {
private:
    int top;    // index of top element
    T info[MAX_ITEMS];  // stack storage
public:
    StackType() 
    { 
        top = -1;
    }
    bool IsEmpty() const 
    { 
        return (top == -1); 
    }
    bool IsFull() const 
    { 
        return (top == MAX_ITEMS - 1); 
    }

    void Push(T newItem) 
    {
        if (IsFull())
        {
            throw FullStack();
        }
        info[++top] = newItem;
    }
    void Pop() 
    {
        if (IsEmpty())
        {
            throw EmptyStack();
        }

        top--;
    }
    T Top() 
    {
        if (IsEmpty()) throw EmptyStack();
        return info[top];
    }
};

// Operator precedence
int precedence(char op) {
    if (op == '^') 
        return 3;
    if (op == '*' || op == '/' || op == '%') 
        return 2;
    if (op == '+' || op == '-')
        return 1;
    return -1;
}
// Check operator
bool isOperator(char ch) {
    return (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^'|| ch== '%');
}
// Check alphabet operand (a-z, A-Z)
bool isLetter(char ch)
{
    return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
}
// Check digit operand (0-9)
bool isDigit(char ch) {
    return (ch >= '0' && ch <= '9');
}

// Validate infix expression
// Ensures brackets balanced, operands/operators in correct sequence
bool isValidExpression(string expr)
{
    int balance = 0;   // track parentheses
    bool lastWasOperator = true;  // expression can't start with operator

    for (int i = 0; i < expr.length();)
    {
        char ch = expr[i];

        if (ch == '(')
        {
            balance++;
            lastWasOperator = true;
            i++;
        }
        else if (ch == ')')
        {
            balance--;
            if (balance < 0)
                return false; // more closing than opening
            lastWasOperator = false;
            i++;
        }
        else if (isOperator(ch))
        {
            if (lastWasOperator)
                return false; // two operators in a row
            lastWasOperator = true;
            i++;
        }
        else if (isLetter(ch))
        {
            if (!lastWasOperator) return false; // two operands in a row
            // only one letter allowed (no ab, no a1, no a(), no (a-b,no a-b), no ((a-b), no (a-b))
            if (i + 1 < expr.length())
            {
                if (isLetter(expr[i + 1]) || isDigit(expr[i + 1]) || expr[i + 1] == '(')
                    return false;
            }
            i++;
            lastWasOperator = false;
        }
        else if (isDigit(ch))
        {
            if (!lastWasOperator) 
                return false;
            while (i < expr.length() && isDigit(expr[i]))
                i++; // multi-digit ok
            // after number, next char cannot be '('
            if (i < expr.length() && expr[i] == '(') 
                return false;
            lastWasOperator = false;
        }
        else
        {
            return false; // invalid character
        }
    }

    return balance == 0 && !lastWasOperator; // balanced parentheses and ends with operand or ')'
}


// Reverse string  (used for infix→prefix)
string reverseString(string s) 
{
    string rev = "";
    for (int i = s.length() - 1; i >= 0; i--)
        rev += s[i];
    return rev;
}

// Infix → Postfix
string InfixToPostfix(string expr) 
{
    StackType<char> s;
    string postfix = "";

    for (int i = 0; i < expr.length();) 
    {
        char ch = expr[i];
        if (isDigit(ch))   // number
        {
            while (i < expr.length() && isDigit(expr[i])) 
                postfix += expr[i++];
            postfix += ' ';
        }
        else if (isLetter(ch))    // single letter operand
        {
            postfix += ch; 
            postfix += ' '; 
            i++;
        }
        else if (ch == '(') 
        {
            s.Push(ch);
            i++; 
        }
        else if (ch == ')')  // pop until '('
        {
            while (!s.IsEmpty() && s.Top() != '(') 
            {
                postfix += s.Top();
                postfix += ' ';
                s.Pop(); 
            }
            if (!s.IsEmpty()) 
                s.Pop();
            i++;
        }
        else if (isOperator(ch))  // pop higher/equal precedence operators
        {
            while (!s.IsEmpty() && precedence(ch) <= precedence(s.Top())) 
            {
                postfix += s.Top(); postfix += ' '; s.Pop();
            }
            s.Push(ch); i++;
        }
    }
    while (!s.IsEmpty())   // pop remaining operators
    { 
        postfix += s.Top();
        postfix += ' ';
        s.Pop();
    }
    return postfix;
}

// Infix → Prefix
string InfixToPrefix(string expr)
{
    string revExpr = reverseString(expr);   // reverse

    for (int i = 0; i < revExpr.length(); i++)  // swap brackets
    {
        if (revExpr[i] == '(') 
            revExpr[i] = ')';
        else if (revExpr[i] == ')') 
            revExpr[i] = '(';
    }
    string postfix = InfixToPostfix(revExpr);  // postfix of reversed
    return reverseString(postfix); // reverse again → prefix
}

int main() {
    StackType<ItemType> s;
    ItemType item;
    int choice, number;

    try {
        while (true) {
            cout << "\nMenu:\n1. Push\n2. Pop\n3. Check Top\n4. Infix to Postfix/Prefix\n5. Exit\nChoice: ";
            cin >> choice;

            if (choice == 1)  // Push integer
            {
                cout << "Enter number to push: ";
                cin >> number;
                item.Initialize(number);
                s.Push(item);
                cout << number << " pushed onto stack.\n";
            }
            else if (choice == 2) // Pop
            {
                cout << "Popped: ";
                s.Top().Print(cout);
                s.Pop();
                cout << endl;
            }
            else if (choice == 3)   
            {         // Show top element
                cout << "Top element: ";
                s.Top().Print(cout);
                cout << endl;
            }
            else if (choice == 4)
            {     // Infix conversion
                string infix;
                cout << "Enter infix expression: ";
                cin.ignore();                // clear leftover newline
                getline(cin, infix);

                if (!isValidExpression(infix)) 
                {
                    cout << "Invalid expression! Please try again.\n";
                }
                else
                {
                    cout << "Postfix: " << InfixToPostfix(infix) << endl;
                    cout << "Prefix: " << InfixToPrefix(infix) << endl;
                }
            }
            else if (choice == 5) 
            {
                cout << "Exiting...\n";
                break;
            }
            else cout << "Invalid choice.\n";
        }
    }
    catch (FullStack) 
    { 
        cout << "Error: Stack is full!\n"; 
    }
    catch (EmptyStack)
    { 
        cout << "Error: Stack is empty!\n"; 
    }

    return 0;
}
