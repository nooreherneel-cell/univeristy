﻿#include<iostream>
#include<fstream>
#include<string>
using namespace std;

const int MAX_ITEMS = 100;
enum RelationType { LESS, GREATER, EQUAL };



// item class
class ItemType
{
private:
	string name;
	string phone_no;
	string address;
public:
	RelationType CompareTo(ItemType other) 
	{
		if (name < other.name)
			return LESS;
		else if (name > other.name) 
			return GREATER;
		else 
			return EQUAL;
	}
	//setters
	void SetName(string n) { name = n; }
	void SetPhone(string p) { phone_no = p; }
	void SetAddress(string a) { address = a; }
	//getters
	string GetName() { return name; }
	string GetPhone() { return phone_no; }
	string GetAddress() { return address; }


	
	
};
// sorted type class
class SortedType
{
private:
	ItemType info[MAX_ITEMS];
	int length;
	int currentPos;   //  position label for iteration

public:
	SortedType() 
	{ 
		length = 0; 
	}

	bool IsFull() 
	{ 
		return (length == MAX_ITEMS);
	}
	bool IsEmpty() 
	{ 
		return (length == 0);
	}
	int LengthIs() 
	{ 
		return length;
	}
	void InsertItem(ItemType item)
	{
		if (IsFull())
		{
			cout << "\n list is full. " << endl;
			return;
		}
		int location = length - 1;
		bool moreToShift = true;
		
		while (moreToShift && location >= 0)
		{
			RelationType compare = item.CompareTo(info[location]);
			switch (compare) 
			{
				case LESS:    // new item < current → shift current right
					info[location + 1] = info[location];
					location--;
					break;

				case EQUAL:   // duplicate found
					cout << "\nContact already exists!\n";
					return;

				case GREATER: // new item > current → found insert position
					moreToShift = false;
					break;
			}
		}
		info[location + 1] = item;
		length++;

	}
	void RetrieveItem(ItemType& item, bool& found) {
		int location = 0;
		found = false;
		bool moreToSearch = (location < length);

		while (moreToSearch && !found) 
		{
			RelationType compare = item.CompareTo(info[location]);
			switch (compare) {
			case LESS:          // item < current → keep searching
			case GREATER:       // item > current → move to next
				location++;
				moreToSearch = (location < length);
				break;
			case EQUAL:         // item found
				found = true;
				item = info[location];
				break;
			}
		}
	}
	void ResetList() 
	{
		currentPos = -1;
	}

	void GetNextItem(ItemType& item) {
		currentPos ++;
		if (currentPos < length)
		{
			item = info[currentPos];
		}
		else
			cout << "No more contacts.\n";
	}
	bool DeleteItem(ItemType item) 
	{
		int location = 0;
		bool moreToSearch = (location < length);
		bool found = false;

		while (moreToSearch && !found) 
		{

			RelationType compare = item.CompareTo(info[location]);
			switch (compare)
			{
			case LESS:     // item < current → continue
			case GREATER:  // item > current → move to next
				location++;
				moreToSearch = (location < length);
				break;

			case EQUAL:    // item found
				found = true;
				// Shift elements left to maintain sorted order
				for (int i = location; i < length - 1; i++) 
				{
					info[i] = info[i + 1];
				}
				length--;
				break;
			}
		}

	 return found ;
	}

	// for filing

	void SaveToFile(string contact) {
		ofstream out(contact,ios::out | ios:: trunc);
		if (!out) {
			cout << "Error opening file for writing.\n";
			return;
		}

		for (int i = 0; i < length; i++)
		{
			out << info[i].GetName() << endl;
			out << info[i].GetPhone() << endl;
			out << info[i].GetAddress() << endl;
		}

		out.close();
		cout << "Contacts saved successfully.\n";
	}

	void LoadFromFile(string contact) {
		ifstream in (contact, ios::in);   // open for reading
		if (!in) {
			cout << "No saved contacts found.\n";
			return;
		}

		length = 0;  // start fresh

		string n, p, a;
		while (getline(in, n) && getline(in, p) && getline(in, a)) {
			ItemType item;
			item.SetName(n);
			item.SetPhone(p);
			item.SetAddress(a);
			InsertItem(item);  // insert in sorted order
		}

		in.close();
		cout << "Contacts loaded successfully.\n";
	}

};
// validity functions 

// Check name: alphabets and spaces only
bool IsValidName(const string& name) 
{
	if (name.empty())
	{
		return false;
	}
	for (int i = 0; i < name.length(); i++)
	{
		if ((name[i] < 'A' || name[i] > 'Z') && (name[i] < 'a' || name[i] > 'z') && name[i] != ' ')
			return false;
	}
	return true;


}

// Check phone: digits only, exact length 11
bool IsValidPhone(const string& phone) {
	if (phone.length() != 11)
	{
		return false;
	}
	for (int i = 0; i < phone.length(); i++)
	{
		if (phone[i] < '0' || phone[i] > '9')
		{
			return false;
		}
	}
	return true;
}

// Check address: non-empty
bool IsValidAddress(const string& address) 
{
	for (int i = 0; i < address.length(); i++) {
		if (address[i] != ' ' && address[i] != '\t') // any non-space character
			return true;
	}
	return false; // empty or all spaces → invalid
}
// main
int main() 
{
	SortedType contacts;
	contacts.LoadFromFile("contacts.txt");  // load saved contacts

	int choice;
	do {
		cout << "\n--- Contact Manager ---\n";
		cout << "1. Add Contact\n";
		cout << "2. Search Contact\n";
		cout << "3. Delete Contact\n";
		cout << "4. Display All Contacts\n";
		cout << "5. Exit\n";
		cout << "Enter your choice: ";
		cin >> choice;
		cin.ignore(); // remove leftover newline

		if (choice == 1) 
		{ 
			// add contact
			string n, p, a;

			cout << "Enter name: ";
			getline(cin, n);
			if (!IsValidName(n)) 
			{ 
				cout << "Invalid name!\n"; 
				continue; // it would go bac to menu without adding if name criteria is invalid
			}

			cout << "Enter phone (11 digits): ";
			getline(cin, p);
			if (!IsValidPhone(p)) 
			{ 
				cout << "Invalid phone!\n";
				continue; // phone num is not between 0 to 9 digits
			}

			cout << "Enter address: ";
			getline(cin, a);
			if (!IsValidAddress(a))
			{
				cout << "Invalid address!Cannot be empty. \n"; 
				continue;  // empty address
			}

			ItemType item;
			item.SetName(n);
			item.SetPhone(p);
			item.SetAddress(a);

			contacts.InsertItem(item);
			contacts.SaveToFile("contacts.txt");  // save after adding

		}
		else if (choice == 2) 
		{
			// Search
			string n;
			cout << "Enter name to search: ";
			getline(cin, n);

			ItemType item;
			item.SetName(n);
			bool found;
			contacts.RetrieveItem(item, found);

			if (found) 
			{
				cout << "Name: " << item.GetName() << endl;
				cout << "Phone: " << item.GetPhone() << endl;
				cout << "Address: " << item.GetAddress() << endl;
			}
			else 
			{
				cout << "Contact not found!\n";
			}

		}
		else if (choice == 3) 
		{	// Delete
			string n;
			cout << "Enter name to delete: ";
			getline(cin, n);

			ItemType item;
			item.SetName(n);
			bool deleted = contacts.DeleteItem(item);

			if (deleted)
			{
				cout << "Contact deleted successfully!\n";
				contacts.SaveToFile("contacts.txt");
			}
			else 
			{
				cout << "Contact not found!\n";
			}


		}
		else if (choice == 4) 
		{	 // Display all
			if (contacts.IsEmpty())
			{
				cout << "No contacts to display.\n";
			}
			else
			{
				contacts.ResetList();
				ItemType item;
				cout << "\n--- All Contacts ---\n";
				for (int i = 0; i < contacts.LengthIs(); i++)
				{
					contacts.GetNextItem(item);
					cout << "Name: " << item.GetName()
						 << ", Phone: " << item.GetPhone()
						 << ", Address: " << item.GetAddress() << endl;
				}
			}

		}
		else if (choice == 5)
		{	 // Exit
			cout << "Exiting...\n";
		}
		else 
		{
			cout << "Invalid choice! Try again.\n";
		}

	} while (choice != 5);

	return 0;
}
