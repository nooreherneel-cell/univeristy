#include <iostream>
#include <string>
using namespace std;

enum RelationType { LESS, GREATER, EQUAL };

// Flight Struct
struct flight
{
    int flightID;
    string dest;
    string depTime; // "HH:MM"
    float duration; // hours
    string status;
    string weather; // for second extra feature

    flight(int id = 0, string d = "", string dt = "", float dur = 0, string s = "", string w = "")
    {
        flightID = id;
        dest = d;
        depTime = dt;
        duration = dur;
        status = s;
        weather = w;
    }

    RelationType ComparedTo(flight other) const
    {
        if (flightID < other.flightID) return LESS;
        else if (flightID > other.flightID) return GREATER;
        else return EQUAL;
    }

    void Print() const
    {
        cout << "Flight ID: " << flightID
            << " | Destination: " << dest
            << " | Departure: " << depTime
            << " | Duration: " << duration << " hrs"
            << " | Status: " << status
            << " | Weather: " << weather;
    }

    int GetValue() const
    {
        return flightID;
    }
};

// BST Node 
struct Node
{
    Node* left;
    Node* right;
    Node* parent;
    flight key;

    Node(flight k)
    {
        key = k;
        left = nullptr;
        right = nullptr;
        parent = nullptr;
    }
};

//  BST Class 
class Bst
{
private:
    Node* root;

public:
    Bst()
    {
        root = nullptr;
    }

    //  BST functions 
    void Transplant(Node* u, Node* v)
    {
        if (!u->parent)
            root = v;
        else if (u == u->parent->left)
            u->parent->left = v;
        else
            u->parent->right = v;
        if (v) v->parent = u->parent;
    }

    Node* search(int k)
    {
        Node* x = root;
        while (x && k != x->key.GetValue())
        {
            if (k < x->key.GetValue())
                x = x->left;
            else
                x = x->right;
        }
        return x;
    }

    Node* minimum(Node* x)
    {
        while (x->left)
            x = x->left;
        return x;
    }

    void Delete(int key)
    {
        Node* z = search(key);
        if (!z)
        {
            cout << "Flight not found!\n";
            return;
        }

        if (!z->left)
            Transplant(z, z->right);
        else if (!z->right)
            Transplant(z, z->left);
        else
        {
            Node* y = minimum(z->right);
            if (y->parent != z)
            {
                Transplant(y, y->right);
                y->right = z->right;
                if (y->right)
                {
                    y->right->parent = y;
                }
            }
            Transplant(z, y);
            y->left = z->left;
            if (y->left)
            {
                y->left->parent = y;
            }
        }
        delete z;
        cout << "Flight deleted successfully.\n\n";
    }

    void insert(int id, string dest = "", string dep = "", float dur = 0, string s = "", string w = "")
    {
        // Prevent duplicate Flight ID
        if (search(id))
        {
            cout << "Flight ID already exists! Insertion failed.\n\n";
            return;
        }

        // Auto-delay logic based on weather
        if (w == "Rain" || w == "Storm" || w == "Foggy")
        {
            cout << " Weather conditions detected. flight marked as Delayed.\n";
            s = "Delayed";
        }
        else if (w == "Sunny")
        {
            cout << "Weather is clear. Flight status stays as entered.\n";
        }
        else
        {
            cout << "Unknown weather type. Flight status stays as entered.\n";
        }
        Node* z = new Node(flight(id, dest, dep, dur, s, w));
        Node* y = nullptr;
        Node* x = root;
        while (x)
        {
            y = x;
            x = (z->key.GetValue() < x->key.GetValue()) ? x->left : x->right;
        }
        z->parent = y;
        if (!y)
            root = z;
        else if (z->key.GetValue() < y->key.GetValue())
        {
            y->left = z;
        }
        else
            y->right = z;

        cout << "Flight inserted successfully.\n";
    }

    void inorder(Node* x)
    {
        if (!x)
            return;
        inorder(x->left);
        x->key.Print();
        cout << endl;
        inorder(x->right);
    }

    void display()
    {
        cout << "\nAll flights (sorted by Flight ID):\n";
        inorder(root);
    }

    //  Display ETA and Punctuality 
    void displayETA(Node* x)
    {
        if (!x)
            return;
        displayETA(x->left);

        int depH = stoi(x->key.depTime.substr(0, 2));
        int depM = stoi(x->key.depTime.substr(3, 2));
        int durH = int(x->key.duration);
        int durM = int((x->key.duration - durH) * 60);

        int etaH = depH + durH + (depM + durM) / 60;
        int etaM = (depM + durM) % 60;
        etaH %= 24;

        string punctuality;
        if (x->key.status == "Landed")
            punctuality = "On-Time";
        else if (x->key.status == "Departed")
            punctuality = "In-Flight";
        else
            punctuality = "Delayed";


        x->key.Print();
        cout << " | ETA: " << (etaH < 10 ? "0" : "") << etaH << ":"
            << (etaM < 10 ? "0" : "") << etaM
            << " | Punctuality: " << punctuality << endl;

        displayETA(x->right);
    }

    void displayAllETA()
    {
        cout << "\nFlights with ETA and Punctuality:\n";
        displayETA(root);
    }

    //Display by Destination
    void displayByDest(Node* x, string dest)
    {
        if (!x)
            return;
        displayByDest(x->left, dest);
        if (x->key.dest == dest)
        {
            x->key.Print();
            cout << endl;
        }
        displayByDest(x->right, dest);
    }
    void DestGather(Node* x, string dests[], int& count)
    {
        if (!x)
            return;
        DestGather(x->left, dests, count);
        bool present = false;
        for (int i = 0; i < count; i++)
        {
            if (dests[i] == x->key.dest)
                present = true;
        }
        if (!present)
        {
            dests[count++] = x->key.dest;
        }
        DestGather(x->right, dests, count);
    }

    void displayDestGrouped()
    {
        cout << "\nFlights Grouped by Destination:\n";
        string dests[100];
        int count = 0;
        DestGather(root, dests, count);

        for (int i = 0; i < count; i++)
        {
            cout << "\nFlights to " << dests[i] << ":\n";
            displayByDest(root, dests[i]);
        }
    }



    // Display by Status 
    void displayByStatus(Node* x, string status)
    {
        if (!x)
            return;
        displayByStatus(x->left, status);
        if (x->key.status == status)
        {
            x->key.Print();
            cout << endl;
        }
        displayByStatus(x->right, status);
    }
    void StatGAther(Node* x, string stats[], int& count)
    {
        if (!x)
            return;
        StatGAther(x->left, stats, count);
        bool present = false;
        for (int i = 0; i < count; i++)
        {
            if (stats[i] == x->key.status)
                present = true;
        }
        if (!present)
            stats[count++] = x->key.status;

        StatGAther(x->right, stats, count);
    }
    void displayStatusGrouped()
    {
        cout << "\nFlights Grouped by Status:\n";
        string stats[100];
        int count = 0;
        StatGAther(root, stats, count);
        for (int i = 0; i < count; i++)
        {
            cout << "\nFlights with status \"" << stats[i] << "\":\n";
            displayByStatus(root, stats[i]);
        }
    }

    // an extra weather feature
    void displayByWeather(Node* x, string weatherType)
    {
        if (!x)
            return;
        displayByWeather(x->left, weatherType);
        if (x->key.weather == weatherType)
        {
            x->key.Print();
            if (x->key.weather != "Sunny" && x->key.status == "Delayed")
                cout << " | Weather Delay";
            else if (x->key.weather == "Sunny")
                cout << " | Weather: Clear";

        }
        displayByWeather(x->right, weatherType);
    }

    void GatherWeather(Node* x, string weathers[], int& count)
    {
        if (!x)
            return;
        GatherWeather(x->left, weathers, count);
        bool present = false;
        for (int i = 0; i < count; i++)
            if (weathers[i] == x->key.weather)
                present = true;

        if (!present)
            weathers[count++] = x->key.weather;

        GatherWeather(x->right, weathers, count);
    }

    void weatherFeature()
    {
        cout << "\nFlights Grouped by Weather:\n";
        string weathers[100];
        int count = 0;
        GatherWeather(root, weathers, count);
        for (int i = 0; i < count; i++)
        {
            cout << "\n| Weather: " << weathers[i] << " |\n";
            displayByWeather(root, weathers[i]);
        }
    }



    // surprise Feature: Longest Flight 
    void findLongestFlight(Node* x, Node*& longest)
    {
        if (!x)
            return;
        if (!longest || x->key.duration > longest->key.duration)
        {
            longest = x;
        }
        findLongestFlight(x->left, longest);
        findLongestFlight(x->right, longest);
    }

    void surpriseFeature()
    {
        Node* longest = nullptr;
        findLongestFlight(root, longest);
        if (longest)
        {
            cout << "\nSurprise Feature: Flight with Longest Duration:\n";
            longest->key.Print();
            cout << " | Duration: " << longest->key.duration << " hrs\n";
        }
        else cout << "No flights available.\n";
    }
};

//  Main Program 
int main()
{
    Bst tree;
    int choice;

    do
    {
        cout << "\n===== Flight Reservation Directory =====";
        cout << "\n1. Insert new flight record";
        cout << "\n2. Delete a flight record";
        cout << "\n3. Search for a flight";
        cout << "\n4. Display all flights (sorted by Flight ID)";
        cout << "\n5. Display flights grouped by destination";
        cout << "\n6. Display flights grouped by status";
        cout << "\n7. Display ETA and punctuality status for all flights";
        cout << "\n8. Display flights by Weather";
        cout << "\n9. Surprise Feature (Longest Flight)";
        cout << "\n10. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice; cin.ignore();

        switch (choice)
        {
        case 1:
        {
            int id;
            string dest, dep, status, weather;
            float dur;
            cout << "\nEnter Flight ID: ";
            cin >> id;
            cin.ignore();
            if (tree.search(id))
            {
                cout << "Flight ID already exists! Insertion failed.\n\n";
                break;
            }
            cout << "Enter Destination: ";
            getline(cin, dest);
            cout << "Enter Departure Time (HH:MM): ";
            getline(cin, dep);
            cout << "Enter Duration (hours): ";
            cin >> dur;
            cin.ignore();
            cout << "Enter Status (Departed/Landed/Delayed): ";
            getline(cin, status);
            cout << "Enter Weather (Sunny/Rain/Storm/Foggy): ";
            getline(cin, weather);
            tree.insert(id, dest, dep, dur, status, weather);
            break;
        }
        case 2:
        {
            int id;
            cout << "\nEnter Flight ID to delete: ";
            cin >> id;
            tree.Delete(id);
            break;
        }
        case 3:
        {
            int id;
            cout << "\nEnter Flight ID to search: ";
            cin >> id;
            Node* result = tree.search(id);
            if (result)
            {
                result->key.Print();
                cout << endl;
            }
            else
                cout << "Flight not found!\n";
            break;
        }
        case 4:
            tree.display();
            break;
        case 5:
            tree.displayDestGrouped();
            break;
        case 6:
            tree.displayStatusGrouped();
            break;
        case 7:
            tree.displayAllETA();
            break;
        case 8:
            tree.weatherFeature();
            break;

        case 9:
            tree.surpriseFeature();
            break;
        case 10:
            cout << "\nExiting program.\n";
            break;

        default:
            cout << "Invalid choice! Try again.\n";
        }

        if (choice != 10)
        {
            cout << "\nPress Enter to continue..";
            cin.ignore();
            cin.get();
        }

    } while (choice != 10);

    return 0;
}










