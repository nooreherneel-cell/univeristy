org 100h

start:
    ; -------------------------
    ; SET TEXT MODE
    ; -------------------------
    mov ax, 0003h        ; 80x25 text mode
    int 10h

    mov ax, cs
    mov ds, ax           ; DS = CS for strings
    
    ; Initialize sound setting (default: on)
    mov byte [sound_enabled], 1
    
; -------------------------
; TITLE SCREEN
; -------------------------
    call clear_screen_blue

    mov si, title_msg
    push si
    push word 11
    push word 26
    push word 0x009E
    call print_text

    mov si, start_msg
    push si
    push word 13
    push word 28
    push word 0x001B
    call print_text

    mov ah, 0
    int 16h

; -------------------------
; MAIN MENU SCREEN
; -------------------------
menu_screen:
    mov byte [menu_selection], 0  ; Reset to first option
    
menu_loop:
    call clear_screen_brown
    call draw_menu

    ; Wait for key press
    mov ah, 0
    int 16h
    
    ; Check for arrow keys or Enter
    cmp ah, 0x48        ; Up arrow
    je move_up_menu
    cmp ah, 0x50        ; Down arrow
    je move_down_menu
    cmp al, 13          ; Enter key
    je select_menu_option
    cmp al, 27          ; ESC key
    je near exit_game
    jmp menu_loop

move_up_menu:
    cmp byte [menu_selection], 0
    jle menu_loop       ; Already at top
    dec byte [menu_selection]
    jmp menu_loop

move_down_menu:
    cmp byte [menu_selection], 3
    jge menu_loop       ; Already at bottom
    inc byte [menu_selection]
    jmp menu_loop

select_menu_option:
    cmp byte [menu_selection], 0
    je near start_game
    cmp byte [menu_selection], 1
    je near show_instructions
    cmp byte [menu_selection], 2
    je near show_options
    cmp byte [menu_selection], 3
    je near exit_game
    jmp menu_loop

draw_menu:
    ; Draw menu title
    mov si, menu_title
    push si
    push word 6
    push word 36
    push word 0x00CB
    call print_text

    ; Option 1 - START GAME
    mov si, opt1
    push si
    push word 10
    push word 34
    cmp byte [menu_selection], 0
    jne near .opt1_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_opt1
.opt1_normal:
    mov ax, 0x002E      ; Yellow on green for normal
.draw_opt1:
    push ax
    call print_text

    ; Option 2 - INSTRUCTIONS
    mov si, opt2
    push si
    push word 12
    push word 34
    cmp byte [menu_selection], 1
    jne .opt2_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_opt2
.opt2_normal:
    mov ax, 0x002E      ; Yellow on green for normal
.draw_opt2:
    push ax
    call print_text

    ; Option 3 - OPTIONS
    mov si, opt3
    push si
    push word 14
    push word 34
    cmp byte [menu_selection], 2
    jne .opt3_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_opt3
.opt3_normal:
    mov ax, 0x002E      ; Yellow on green for normal
.draw_opt3:
    push ax
    call print_text

    ; Option 4 - EXIT
    mov si, opt4
    push si
    push word 16
    push word 34
    cmp byte [menu_selection], 3
    jne near .opt4_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_opt4
.opt4_normal:
    mov ax, 0x002E      ; Yellow on green for normal
.draw_opt4:
    push ax
    call print_text

    ; Draw navigation instructions
    mov si, menu_nav
    push si
    push word 22
    push word 10
    push word 0x000E
    call print_text

    ret

; -------------------------
; OPTIONS MENU
; -------------------------
show_options:
    mov byte [options_selection], 0  ; Reset to first option
    
options_loop:
    call clear_screen_white
    call draw_options_menu

    ; Wait for key press
    mov ah, 0
    int 16h
    
    ; Check for arrow keys, Enter, or T for toggle
    cmp ah, 0x48        ; Up arrow
    je move_up_options
    cmp ah, 0x50        ; Down arrow
    je move_down_options
    cmp al, 13          ; Enter key
    je select_options_option
    cmp al, 27          ; ESC key
    je near menu_screen
    cmp al, 't'
    je near toggle_sound
    cmp al, 'T'
    je near toggle_sound
    jmp options_loop

move_up_options:
    cmp byte [options_selection], 0
    jle options_loop    ; Already at top
    dec byte [options_selection]
    jmp options_loop

move_down_options:
    cmp byte [options_selection], 1
    jge options_loop    ; Already at bottom
    inc byte [options_selection]
    jmp options_loop

select_options_option:
    cmp byte [options_selection], 0
    je near toggle_sound
    cmp byte [options_selection], 1
    je near menu_screen
    jmp options_loop

draw_options_menu:
    ; Draw options title
    mov si, options_title
    push si
    push word 6
    push word 34
    push word 0x001F
    call print_text

    ; Option 1 - Sound toggle
    mov si, sound_option
    push si
    push word 10
    push word 28
    cmp byte [options_selection], 0
    jne .sound_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_sound
.sound_normal:
    mov ax, 0x001E      ; Yellow on blue for normal
.draw_sound:
    push ax
    call print_text

    ; Display sound status
    cmp byte [sound_enabled], 1
    jne .sound_off
    
    ; Sound ON
    mov si, sound_on
    push si
    push word 10
    push word 50
    cmp byte [options_selection], 0
    jne .sound_on_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_sound_status
.sound_on_normal:
    mov ax, 0x002A      ; Green on green for normal
.draw_sound_status:
    push ax
    call print_text
    jmp .after_sound

.sound_off:
    ; Sound OFF
    mov si, sound_off
    push si
    push word 10
    push word 50
    cmp byte [options_selection], 0
    jne .sound_off_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_sound_status2
.sound_off_normal:
    mov ax, 0x004C      ; Red on red for normal
.draw_sound_status2:
    push ax
    call print_text

.after_sound:
    ; Option 2 - Back
    mov si, back_option
    push si
    push word 14
    push word 28
    cmp byte [options_selection], 1
    jne .back_normal
    mov ax, 0x0070      ; Black on white (inverse) for selected
    jmp .draw_back
.back_normal:
    mov ax, 0x00C0      ; Black on red for normal
.draw_back:
    push ax
    call print_text

    ; Draw navigation instructions
    mov si, options_nav
    push si
    push word 18
    push word 20
    push word 0x000E
    call print_text

    ret

toggle_sound:
    xor byte [sound_enabled], 1    ; Toggle sound setting
    
    ; Play a confirmation sound when turning sound ON
    cmp byte [sound_enabled], 1
    jne .sound_off_skip
    
    ; Play a beep when turning sound ON
    push ax
    push bx
    push cx
    push dx
    
    mov al, 182
    out 43h, al
    mov ax, 3619        ; Different frequency for toggle confirmation
    out 42h, al
    mov al, ah
    out 42h, al
    in al, 61h
    or al, 00000011b
    out 61h, al
    
    ; Short delay
    mov cx, 1
    mov dx, 0
    mov ah, 86h
    int 15h
    
    ; Turn off speaker
    in al, 61h
    and al, 11111100b
    out 61h, al
    
    pop dx
    pop cx
    pop bx
    pop ax
    
.sound_off_skip:
    jmp options_loop
; -------------------------
; START GAME
; -------------------------
start_game:
    mov word [score], 0
    call clear_screen_white
    call reset_elements
    call draw_all_elements
    call draw_player
    call draw_score

game_loop:
    ; Update blink animation
    call update_animations
    
    ; Check for key press without blocking
    mov ah, 1
    int 16h
    jz near no_key_pressed
    
    ; Key was pressed - read and process it
    mov ah, 0
    int 16h

    call erase_player

    cmp al, 'w'
    je move_up
    cmp al, 'W'
    je move_up
    cmp al, 's'
    je move_down
    cmp al, 'S'
    je move_down
    cmp al, 'a'
    je move_left
    cmp al, 'A'
    je move_left
    cmp al, 'd'
    je move_right
    cmp al, 'D'
    je move_right
    cmp al, 27
    je near end_game
     
    ; For non-movement keys, still check collisions
    call check_all_collisions
    jmp redraw

move_up:
    dec word [player_row]
    jmp after_move

move_down:
    inc word [player_row]
    jmp after_move

move_left:
    dec word [player_col]
    jmp after_move

move_right:
    inc word [player_col]
    jmp after_move

after_move:
    ; Bounds checking
    cmp word [player_row], 0
    jl set_min_row
    cmp word [player_row], 24
    jg set_max_row
    cmp word [player_col], 0
    jl set_min_col
    cmp word [player_col], 79
    jg set_max_col
    jmp do_collision_check

set_min_row:
    mov word [player_row], 0
    jmp do_collision_check

set_max_row:
    mov word [player_row], 24
    jmp do_collision_check

set_min_col:
    mov word [player_col], 0
    jmp do_collision_check

set_max_col:
    mov word [player_col], 79
    jmp do_collision_check

do_collision_check:
    call check_all_collisions
    jmp redraw

no_key_pressed:
    ; No key pressed, just continue with animation

redraw:
    ; Always redraw everything to show animations
    call draw_all_elements
    call draw_player
    
    ; Small delay to control animation speed
    mov cx, 1
    mov dx, 0
    mov ah, 86h
    int 15h
    
    cmp word [score], 5
    jge near win_screen
    jmp game_loop

end_game:
    jmp near menu_screen

win_screen:
    call clear_screen_green
    mov si, win_msg
    push si
    push word 12
    push word 30
    push word 0x004F    ; White on red (celebration!)
    call print_text

    ; Add a victory subtitle
    mov si, victory_submsg
    push si
    push word 14
    push word 34
    push word 0x002E      ; Yellow on green
    call print_text

    mov ah, 0
    int 16h
    jmp near menu_screen

exit_game:
    call clear_screen_blue
    mov si, debug_msg
    push si
    push word 12
    push word 30
    push word 0x001E
    call print_text
    
    mov ah, 0
    int 16h

    mov ax, 0003h
    int 10h
    mov ax, cs
    mov ds, ax
    mov es, ax

    mov ax, 0x4C00
    int 0x21

; -------------------------
; GAME VARIABLES
; -------------------------
player_row dw 12
player_col dw 40
score      dw 0
blink_counter db 0
blink_state db 0
sound_enabled db 1    ; 1 = sound on, 0 = sound off
menu_selection db 0   ; 0-3 for main menu options
options_selection db 0 ; 0-1 for options menu

; Element positions (row, col) for 7 elements
element1_row dw 5
element1_col dw 20
element2_row dw 8
element2_col dw 60
element3_row dw 15
element3_col dw 15
element4_row dw 18
element4_col dw 70
element5_row dw 10
element5_col dw 35
element6_row dw 20
element6_col dw 50
element7_row dw 3
element7_col dw 45

; Element collection status (0=not collected, 1=collected)
element1_collected db 0
element2_collected db 0
element3_collected db 0
element4_collected db 0
element5_collected db 0
element6_collected db 0
element7_collected db 0

; -------------------------
; GAME FUNCTIONS
; -------------------------
; Update animation states - MAKE IT FASTER
update_animations:
    inc byte [blink_counter]
    cmp byte [blink_counter], 2  ; Faster blinking - change every 2 frames
    jb .done
    mov byte [blink_counter], 0
    xor byte [blink_state], 1    ; Toggle blink state
.done:
    ret

; Reset all elements to not collected
reset_elements:
    mov byte [element1_collected], 0
    mov byte [element2_collected], 0
    mov byte [element3_collected], 0
    mov byte [element4_collected], 0
    mov byte [element5_collected], 0
    mov byte [element6_collected], 0
    mov byte [element7_collected], 0
    ret

; SIMPLIFIED collision detection - check if player is on same position as element
check_all_collisions:
    ; Check element 1
    cmp byte [element1_collected], 0
    je .check1
    jmp .check2
.check1:
    mov ax, [player_row]
    cmp ax, [element1_row]
    jne .check2
    mov ax, [player_col]
    cmp ax, [element1_col]
    jne .check2
    ; Collision with element 1
    mov byte [element1_collected], 1
    inc word [score]
    call draw_score
    
    ; Play sound if enabled
    cmp byte [sound_enabled], 1
    jne .no_sound1
    call play_collect_sound
.no_sound1:
    call erase_element1
    jmp .done_check

.check2:
    cmp byte [element2_collected], 0
    je .check2a
    jmp .check3
.check2a:
    mov ax, [player_row]
    cmp ax, [element2_row]
    jne .check3
    mov ax, [player_col]
    cmp ax, [element2_col]
    jne .check3
    ; Collision with element 2
    mov byte [element2_collected], 1
    inc word [score]
    call draw_score
    
    ; Play sound if enabled
    cmp byte [sound_enabled], 1
    jne .no_sound2
    call play_collect_sound
.no_sound2:
    call erase_element2
    jmp .done_check

.check3:
    cmp byte [element3_collected], 0
    je .check3a
    jmp .check4
.check3a:
    mov ax, [player_row]
    cmp ax, [element3_row]
    jne .check4
    mov ax, [player_col]
    cmp ax, [element3_col]
    jne .check4
    ; Collision with element 3
    mov byte [element3_collected], 1
    inc word [score]
    call draw_score
    
    ; Play sound if enabled
    cmp byte [sound_enabled], 1
    jne .no_sound3
    call play_collect_sound
.no_sound3:
    call erase_element3
    jmp .done_check

.check4:
    cmp byte [element4_collected], 0
    je .check4a
    jmp .check5
.check4a:
    mov ax, [player_row]
    cmp ax, [element4_row]
    jne .check5
    mov ax, [player_col]
    cmp ax, [element4_col]
    jne .check5
    ; Collision with element 4
    mov byte [element4_collected], 1
    inc word [score]
    call draw_score
    
    ; Play sound if enabled
    cmp byte [sound_enabled], 1
    jne .no_sound4
    call play_collect_sound
.no_sound4:
    call erase_element4
    jmp .done_check

.check5:
    cmp byte [element5_collected], 0
    je .check5a
    jmp .check6
.check5a:
    mov ax, [player_row]
    cmp ax, [element5_row]
    jne .check6
    mov ax, [player_col]
    cmp ax, [element5_col]
    jne .check6
    ; Collision with element 5
    mov byte [element5_collected], 1
    inc word [score]
    call draw_score
    
    ; Play sound if enabled
    cmp byte [sound_enabled], 1
    jne .no_sound5
    call play_collect_sound
.no_sound5:
    call erase_element5
    jmp .done_check

.check6:
    cmp byte [element6_collected], 0
    je .check6a
    jmp .check7
.check6a:
    mov ax, [player_row]
    cmp ax, [element6_row]
    jne .check7
    mov ax, [player_col]
    cmp ax, [element6_col]
    jne .check7
    ; Collision with element 6
    mov byte [element6_collected], 1
    inc word [score]
    call draw_score
    
    ; Play sound if enabled
    cmp byte [sound_enabled], 1
    jne .no_sound6
    call play_collect_sound
.no_sound6:
    call erase_element6
    jmp .done_check

.check7:
    cmp byte [element7_collected], 0
    je .check7a
    jmp .done_check
.check7a:
    mov ax, [player_row]
    cmp ax, [element7_row]
    jne .done_check
    mov ax, [player_col]
    cmp ax, [element7_col]
    jne .done_check
    ; Collision with element 7
    mov byte [element7_collected], 1
    inc word [score]
    call draw_score
    
    ; Play sound if enabled
    cmp byte [sound_enabled], 1
    jne .no_sound7
    call play_collect_sound
.no_sound7:
    call erase_element7

.done_check:
    ret

; -------------------------
; SOUND FUNCTION
; -------------------------
play_collect_sound:
    push ax
    push bx
    push cx
    push dx
    
    ; Play a beep using PC speaker
    mov al, 182
    out 43h, al
    mov ax, 4560        ; Frequency (middle C)
    out 42h, al
    mov al, ah
    out 42h, al
    in al, 61h
    or al, 00000011b
    out 61h, al
    
    ; Short delay
    mov cx, 1
    mov dx, 0
    mov ah, 86h
    int 15h
    
    ; Turn off speaker
    in al, 61h
    and al, 11111100b
    out 61h, al
    
    pop dx
    pop cx
    pop bx
    pop ax
    ret

; -------------------------
; DRAW/ERASE FUNCTIONS
; -------------------------

draw_player:
    push ax
    push bx
    push cx
    push di
    push es
    
    mov ax, 0B800h
    mov es, ax
    
    mov ax, [player_row]
    mov bx, 80
    mul bx
    add ax, [player_col]
    shl ax, 1
    mov di, ax

    mov al, 2          ; Smiley face symbol (ASCII 2) - the hero!
    mov ah, 0x00CE   ; Yellow on blue
    mov [es:di], ax

    pop es
    pop di
    pop cx
    pop bx
    pop ax
    ret

erase_player:
    push ax
    push bx
    push cx
    push di
    push es
    
    mov ax, 0B800h
    mov es, ax
    
    mov ax, [player_row]
    mov bx, 80
    mul bx
    add ax, [player_col]
    shl ax, 1
    mov di, ax

    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax

    pop es
    pop di
    pop cx
    pop bx
    pop ax
    ret

; Draw all elements with blinking
draw_all_elements:
    call draw_element1
    call draw_element2
    call draw_element3
    call draw_element4
    call draw_element5
    call draw_element6
    call draw_element7
    ret

; Individual element draw functions with blinking
; Individual element draw functions with SIMPLE blinking
draw_element1:
    cmp byte [element1_collected], 1
    je .done
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element1_row]
    mov bx, 80
    mul bx
    add ax, [element1_col]
    shl ax, 1
    mov di, ax
    
    ; Simple blinking - just change color
    cmp byte [blink_state], 0
    je .normal1
    mov al, '*'      ; Use asterisk for blinking
    mov ah, 0Eh      ; Bright yellow
    jmp .draw1
.normal1:
    mov al, '$'      ; Dollar sign (normal)
    mov ah, 0Ch      ; Red
.draw1:
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
.done:
    ret

draw_element2:
    cmp byte [element2_collected], 1
    je .done
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element2_row]
    mov bx, 80
    mul bx
    add ax, [element2_col]
    shl ax, 1
    mov di, ax
    cmp byte [blink_state], 0
    je .normal2
    mov al, '*'      ; Asterisk for blinking
    mov ah, 0Eh      ; Bright yellow
    jmp .draw2
.normal2:
    mov al, '$'
    mov ah, 0Ah      ; Green
.draw2:
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
.done:
    ret

draw_element3:
    cmp byte [element3_collected], 1
    je .done
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element3_row]
    mov bx, 80
    mul bx
    add ax, [element3_col]
    shl ax, 1
    mov di, ax
    cmp byte [blink_state], 0
    je .normal3
    mov al, '*'      ; Asterisk for blinking
    mov ah, 0Eh      ; Bright yellow
    jmp .draw3
.normal3:
    mov al, '$'
    mov ah, 0Eh      ; Yellow
.draw3:
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
.done:
    ret

draw_element4:
    cmp byte [element4_collected], 1
    je .done
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element4_row]
    mov bx, 80
    mul bx
    add ax, [element4_col]
    shl ax, 1
    mov di, ax
    cmp byte [blink_state], 0
    je .normal4
    mov al, '*'      ; Asterisk for blinking
    mov ah, 0Eh      ; Bright yellow
    jmp .draw4
.normal4:
    mov al, '$'
    mov ah, 0Dh      ; Magenta
.draw4:
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
.done:
    ret

draw_element5:
    cmp byte [element5_collected], 1
    je .done
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element5_row]
    mov bx, 80
    mul bx
    add ax, [element5_col]
    shl ax, 1
    mov di, ax
    cmp byte [blink_state], 0
    je .normal5
    mov al, '*'      ; Asterisk for blinking
    mov ah, 0Eh      ; Bright yellow
    jmp .draw5
.normal5:
    mov al, '$'
    mov ah, 0Bh      ; Cyan
.draw5:
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
.done:
    ret

draw_element6:
    cmp byte [element6_collected], 1
    je .done
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element6_row]
    mov bx, 80
    mul bx
    add ax, [element6_col]
    shl ax, 1
    mov di, ax
    cmp byte [blink_state], 0
    je .normal6
    mov al, '*'      ; Asterisk for blinking
    mov ah, 0Eh      ; Bright yellow
    jmp .draw6
.normal6:
    mov al, '$'
    mov ah, 09h      ; Blue
.draw6:
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
.done:
    ret

draw_element7:
    cmp byte [element7_collected], 1
    je .done
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element7_row]
    mov bx, 80
    mul bx
    add ax, [element7_col]
    shl ax, 1
    mov di, ax
    cmp byte [blink_state], 0
    je .normal7
    mov al, '*'      ; Asterisk for blinking
    mov ah, 0Eh      ; Bright yellow
    jmp .draw7
.normal7:
    mov al, '$'
    mov ah, 0Eh      ; Yellow
.draw7:
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
.done:
    ret

; Individual element erase functions
erase_element1:
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element1_row]
    mov bx, 80
    mul bx
    add ax, [element1_col]
    shl ax, 1
    mov di, ax
    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
    ret

erase_element2:
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element2_row]
    mov bx, 80
    mul bx
    add ax, [element2_col]
    shl ax, 1
    mov di, ax
    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
    ret

erase_element3:
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element3_row]
    mov bx, 80
    mul bx
    add ax, [element3_col]
    shl ax, 1
    mov di, ax
    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
    ret

erase_element4:
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element4_row]
    mov bx, 80
    mul bx
    add ax, [element4_col]
    shl ax, 1
    mov di, ax
    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
    ret

erase_element5:
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element5_row]
    mov bx, 80
    mul bx
    add ax, [element5_col]
    shl ax, 1
    mov di, ax
    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
    ret

erase_element6:
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element6_row]
    mov bx, 80
    mul bx
    add ax, [element6_col]
    shl ax, 1
    mov di, ax
    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
    ret

erase_element7:
    push ax
    push bx
    push di
    push es
    mov ax, 0B800h
    mov es, ax
    mov ax, [element7_row]
    mov bx, 80
    mul bx
    add ax, [element7_col]
    shl ax, 1
    mov di, ax
    mov al, ' '
    mov ah, 0Fh
    mov [es:di], ax
    pop es
    pop di
    pop bx
    pop ax
    ret

; -------------------------
; DRAW SCORE
; -------------------------
draw_score:
    push ax
    push bx
    push cx
    push di
    push es
    
    mov ax, 0B800h
    mov es, ax
    mov di, 0
    
    ; Draw "SCORE: " text
    mov al, 'S'
    mov ah, 0Fh
    mov [es:di], ax
    add di, 2
    mov al, 'C'
    mov [es:di], ax
    add di, 2
    mov al, 'O'
    mov [es:di], ax
    add di, 2
    mov al, 'R'
    mov [es:di], ax
    add di, 2
    mov al, 'E'
    mov [es:di], ax
    add di, 2
    mov al, ':'
    mov [es:di], ax
    add di, 2
    mov al, ' '
    mov [es:di], ax
    add di, 2
    
    ; Draw score number
    mov ax, [score]
    add al, '0'      ; Convert to ASCII
    mov ah, 1Fh
    mov [es:di], ax

    pop es
    pop di
    pop cx
    pop bx
    pop ax
    ret

; -------------------------
; CLEAR SCREEN FUNCTIONS
; -------------------------
clear_screen_white:
    push es 
    mov ax, 0B800h
    mov es, ax
    xor di, di
    mov cx, 2000
    mov ax, 0xF020
.cls_white_loop:
    mov [es:di], ax
    add di, 2
    loop .cls_white_loop
    pop es
    ret

clear_screen_blue:
    push es 
    mov ax, 0B800h
    mov es, ax
    xor di, di
    mov cx, 2000
    mov ax, 0x1F20
.cls_blue_loop:
    mov [es:di], ax
    add di, 2
    loop .cls_blue_loop
    pop es
    ret
clear_screen_green:
    push es 
    mov ax, 0B800h
    mov es, ax
    xor di, di
    mov cx, 2000
    mov ax, 0xEA2A     ; dark brown background with blinking green  '*' character for pattern
.cls_green_loop:
    mov [es:di], ax
    add di, 2
    loop .cls_green_loop
    pop es
    ret

clear_screen_brown:
    push es 
    mov ax, 0B800h
    mov es, ax
    xor di, di
    mov cx, 2000
    mov ax, 0x6020      ; Brown background (0x6), black text (0x0), space char
.brown_loop:
    mov [es:di], ax
    add di, 2
    loop .brown_loop
    pop es
    ret; -------------------------
; PRINT TEXT FUNCTION
; -------------------------
print_text:
    push bp
    mov bp, sp
    push bx
    push cx
    push dx
    push di
    push si
    push es

    ; Get parameters from stack
    mov si, [bp+10]          ; String pointer
    mov bx, [bp+8]           ; Row
    mov dx, [bp+6]           ; Column
    
    ; Get color attribute
    mov ax, [bp+4]           ; Get the WORD (e.g., 0x001E)
    push ax                  ; Save color on stack
    
    ; Set ES to video memory
    mov ax, 0B800h
    mov es, ax

    ; Calculate position: (row * 80 + col) * 2
    mov al, 80               ; AL = 80
    mul bl                   ; AX = row * 80
    add ax, dx               ; AX = row * 80 + column
    shl ax, 1                ; AX = (row * 80 + column) * 2
    mov di, ax               ; DI = video memory offset

    ; Get color from stack
    pop ax                   ; AX = color word
    mov ah, al               ; AH = color byte

.print_loop:
    lodsb                    ; Load character from DS:SI into AL, increment SI
    test al, al              ; Check for null terminator
    jz .done
    
    stosw                    ; Store AX (AL=char, AH=color) at ES:DI, increment DI by 2
    jmp .print_loop

.done:
    pop es
    pop si
    pop di
    pop dx
    pop cx
    pop bx
    pop bp
    ret 8

; -------------------------
; INSTRUCTIONS
; -------------------------
show_instructions:
    call clear_screen_blue
    mov si, instr_msg
    push si
    push word 11
    push word 15
    push word 0x000E
    call print_text
    
    mov si, instr_msg2
    push si
    push word 13
    push word 15
    push word 0x0009
    call print_text
    
    ; Add navigation instructions
    mov si, instr_nav
    push si
    push word 20
    push word 20
    push word 0x000E
    call print_text
    
    mov ah, 0
    int 16h
    jmp near menu_screen

; -------------------------
; STRINGS
; -------------------------
title_msg db 'WELCOME TO THE ADVENTURE GAME',0
start_msg db 'PRESS ANY KEY TO START...',0
menu_title db 'MAIN MENU',0
opt1 db 'START GAME',0
opt2 db 'INSTRUCTIONS',0
opt3 db 'OPTIONS',0
opt4 db 'EXIT',0
menu_nav db 'USE ARROW KEYS TO NAVIGATE, ENTER TO SELECT, ESC TO EXIT',0
instr_msg db 'USE W/A/S/D TO MOVE. COLLECT 5 DIAMONDS TO WIN!',0
instr_msg2 db 'PRESS ESC TO RETURN TO MENU.',0
instr_nav db 'PRESS ANY KEY TO RETURN TO MENU',0
debug_msg db 'EXITING GAME...',0
win_msg db '<3 YOU WIN! SCORE REACHED 5 ',0
options_title db 'OPTIONS MENU',0
sound_option db 'SOUND:',0
sound_on db 'ON',0
sound_off db 'OFF',0
options_nav db ' USE ARROW KEYS, ENTER TO TOGGLE, ESC TO RETURN',0
back_option db 'BACK TO MAIN MENU',0
victory_submsg db 'VICTORY!',0